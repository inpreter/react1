import React from 'react';

class Todo extends React.Component {
  render() {
    return <div>TODO</div>;
  }
}

export default Todo;
