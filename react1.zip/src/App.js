import React, { Component } from 'react';
import './App.css';
import Game from './Game';
import Todo from './todo/Todo';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Game />
        <Todo />
      </div>
    );
  }
}

export default App;
